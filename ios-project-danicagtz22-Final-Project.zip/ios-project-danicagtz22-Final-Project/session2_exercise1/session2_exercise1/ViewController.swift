//
//  ViewController.swift
//  session2_exercise1
//
//  Created by Danica Gutierrez 1 on 3/31/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

