//
//  Note.swift
//  AngryDogs2
//
//  Created by Danica Gutierrez 1 on 5/8/23.
//

import Foundation
import CoreData

@objc(Note)
class Note: NSManagedObject
{
    @NSManaged var id: NSNumber!
    @NSManaged var noteDescription: String!
    @NSManaged var dogBreed: String!
    @NSManaged var deletedDate: Date?
    
}
