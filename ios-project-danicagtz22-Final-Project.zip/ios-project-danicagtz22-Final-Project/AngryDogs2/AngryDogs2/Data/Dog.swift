//
//  Dog.swift
//  AngryDogs2
//
//  Created by Danica Gutierrez 1 on 4/6/23.
//

import Foundation

class Dog: CustomDebugStringConvertible, Codable  {
    var debugDescription: String {
        return "Dog(name: \(self.name), description: \(self.description))"
    }
    
    var name: String
    var description: String
    var imageUrl: String
    var avgWeight: String
    var avgExpectancy: String
    var kennelURL: String
    var note: Note?

    //var dogNote: Note
    var isFavorite: Bool = false
    var confirmFavorite: Bool = false
    
    private enum CodingKeys: String, CodingKey {
        case name, description, imageUrl, avgWeight, avgExpectancy, kennelURL
    }
    
    init(named name: String, description: String, imageUrl: String, avgWeight: String, avgExpectancy: String, kennelURL: String){
        self.name = name
        self.description = description
        self.imageUrl = imageUrl
        self.avgWeight = avgWeight
        self.avgExpectancy = avgExpectancy
        self.kennelURL = kennelURL
    }
}

struct DogResult: Codable {
    let dogs: [Dog]
}
