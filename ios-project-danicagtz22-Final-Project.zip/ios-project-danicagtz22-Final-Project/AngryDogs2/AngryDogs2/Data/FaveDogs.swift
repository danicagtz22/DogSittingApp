//
//  FaveDogs.swift
//  AngryDogs2
//
//  Created by Danica Gutierrez 1 on 5/11/23.
//

import Foundation
import CoreData

@objc(FaveDogs)
public class FaveDogs: NSManagedObject
{
    @NSManaged var favoriteDogURL: String?
    @NSManaged var favoriteDogDescription: String?
    @NSManaged var favoriteDogImage: String?
    @NSManaged var favoriteDogName: String?
    
}
