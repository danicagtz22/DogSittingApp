//
//  DogService.swift
//  AngryDogs2
//
//  Created by Danica Gutierrez 1 on 4/6/23.
//

import Foundation

enum DogCallingError: Error {
    case problemGeneratingURL
    case problemGettingDataFromAPI
    case problemDecodingData
}



class DogService {
    
    private let urlString = "https://run.mocky.io/v3/3b22ed0a-78dd-4883-a123-096541f6b86a"
// "https://run.mocky.io/v3/26fed301-4766-4add-8fd7-9e8d19a9ce36"
    
    func getDogs(completion: @escaping ([Dog]?, Error?) -> ()){
        guard let url = URL(string: self.urlString) else {
            DispatchQueue.main.async { completion(nil, DogCallingError.problemGeneratingURL) }
            return
        }
        
        let request = URLRequest(url: url)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                DispatchQueue.main.async { completion(nil, DogCallingError.problemGettingDataFromAPI) }
                return
            }
            do {
                if !data.isEmpty{
                    let dogResult = try JSONDecoder().decode(DogResult.self, from: data)
                    DispatchQueue.main.async { completion(dogResult.dogs, nil) }
                } else {
                    print ("The data list received from api is empty")
                }
            } catch ( let error) {
                print(error)
                DispatchQueue.main.async {completion (nil, DogCallingError.problemDecodingData) }
            }
        }
        
        task.resume()
    }
}
