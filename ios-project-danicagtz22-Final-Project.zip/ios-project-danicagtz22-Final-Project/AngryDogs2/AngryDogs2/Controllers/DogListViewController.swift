//
//  ViewController.swift
//  AngryDogs2
//
//  Created by Danica Gutierrez 1 on 3/30/23.
//

import UIKit
import CoreData

var packGlobal: [Dog] = []
class DogListViewController: UIViewController {

    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    
    var firstLoad = true
    var pack: [Dog] = []
    var dogService: DogService!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.dogService = DogService()
        spinner.hidesWhenStopped = true
        spinner.startAnimating()
        
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        //this is for the favorites feature sake
        if(firstLoad){
            firstLoad = false
        }
        
    }
    

    override func viewWillAppear(_ animated: Bool) {
        
        spinner.stopAnimating()
        guard let confirmedService = self.dogService
        else { self.showAlert()
            return
        }
        
        confirmedService.getDogs(completion: {dogs, error in
            guard let dogs = dogs, error == nil else{
               self.showAlert()
                return
            }
            self.pack = dogs
            packGlobal = dogs
            self.tableView.reloadData()
        })
    }
    //prepare allows us to pass data to the detail view controller 
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard
            let destination = segue.destination as? DetailViewController,
            let selectedIndexPath = self.tableView.indexPathForSelectedRow,
            let confirmedCell = self.tableView.cellForRow(at: selectedIndexPath) as? DogCellTableViewCell
            else { return }
        
        let confirmedDog = confirmedCell.dog
        destination.dog = confirmedDog
    
    }
    
    func showAlert() {
            let alert = UIAlertController(title: "Connection Error", message: "Issue fetching data, check your connection", preferredStyle: .alert)


            //actions
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in print("Cancel")
            }))
            //show alert
        self.present(alert, animated: true, completion: nil)

    }
    
}
    
    extension DogListViewController: UITableViewDataSource {
        //MARK: DataSource
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return self.pack.count
            }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let cell = self.tableView.dequeueReusableCell(withIdentifier: "dogCell") as! DogCellTableViewCell
            
            
            let currentDog = self.pack[indexPath.row]
            
            
            cell.dog = currentDog
            
            return cell
        }
    }
    
    extension DogListViewController: UITableViewDelegate {
        //MARK: Delegate
        
        func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
            
            
            //getting data from source
            let cell = self.tableView.cellForRow(at: indexPath) as? DogCellTableViewCell
            
            let favorite = cell?.dog?.isFavorite

            
            let liked = UIImageView(frame: CGRect(x:0, y: 70, width: 35, height: 32))
            liked.image = UIImage(systemName: "heart.fill")
            liked.tintColor = .systemRed
            
            
            
            let title = favorite! ?
                NSLocalizedString("Unfavorite", comment: "Unfavorite") :
                NSLocalizedString("Favorite", comment: "Favorite")

              let action = UIContextualAction(style: .normal, title: title,
                handler: { (action, view, completionHandler) in
                // Update data source when user taps action
                 // if the dog is not currently a favorite, make it a favorite and save it to core data
                  if ((cell?.dog?.isFavorite == false) && !self.firstLoad) {

                      cell?.dog?.isFavorite = true
                      let appDelegate = UIApplication.shared.delegate as! AppDelegate
                      let context = appDelegate.persistentContainer.viewContext
                      //In-memory changes should take precedence over external changes
                      context.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
                      let entity = NSEntityDescription.entity(forEntityName: "FaveDogs", in: context)
                      let faveDog = NSManagedObject(entity: entity!, insertInto: context)
                      faveDog.setValue(cell?.dog?.name, forKey: "favoriteDogName" )
                      faveDog.setValue(cell?.dog?.description, forKey: "favoriteDogDescription" )
                      faveDog.setValue(cell?.dog?.imageUrl, forKey: "favoriteDogImage" )
                      faveDog.setValue(cell?.dog?.kennelURL, forKey: "favoriteDogURL")
                      do {
                          try context.save()

                      }catch{
                          print("context save error for favorites")
                      }
                  }//the dog is already a favorite, so we unfavorite and save it to core data
                  else{
                      cell?.dog?.isFavorite = false

                    //fetch the result from core data
                      let appDelegate = UIApplication.shared.delegate as! AppDelegate
                      let context = appDelegate.persistentContainer.viewContext
                      let requestf = NSFetchRequest<NSFetchRequestResult>(entityName: "FaveDogs")
                      do {
                          let results: NSArray = try context.fetch(requestf) as NSArray
                          for result in results
                          {
                              let faveDoggy = result as! FaveDogs
                              if(faveDoggy.favoriteDogName == cell?.dog?.name){
                                  context.delete(faveDoggy)
                                  try context.save()
                              }
                          }
                      }catch{
                          print("there was an error deleting dog from favorites")
                      }
                  }
                  
                  //this adds a visual effect to the action
                  cell?.accessoryView = (cell?.dog!.isFavorite)! ? liked : .none

                completionHandler(true)
              })

            action.title = favorite! ? "Unfavorite!" : "Favorite!"
              action.backgroundColor = favorite! ? .red : .green
              let configuration = UISwipeActionsConfiguration(actions: [action])
              return configuration
        }

        
    }

