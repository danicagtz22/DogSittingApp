
import Foundation
import UIKit
import WebKit

class WebViewControllerDog: UIViewController, WKNavigationDelegate {
    
    var favDog: FaveDogs!
    
    var webView: WKWebView!
    
    override func loadView() {
        webView = WKWebView()
        webView.navigationDelegate = self
        view = webView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let stringUrl: String! = favDog.favoriteDogURL
        //This is what will modify the URL according to the dog breed.
        let url = URL(string: stringUrl)!
        webView.load(URLRequest(url: url))
        webView.allowsBackForwardNavigationGestures = true
    }
    
    
    
    
}
