
import UIKit
import CoreData
import Foundation


class FavoritesController: UIViewController {

@IBOutlet weak var tableView: UITableView!
       
    //Data source will come from core data
    var favePack = [FaveDogs]()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //import favorite dog data
        importFaveDoggos()
        self.tableView.reloadData()
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        importFaveDoggos()
        self.tableView.reloadData()
        
    }
    //prepare allows us to pass data to the detail view controller
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        guard
            let destination = segue.destination as? WebViewControllerDog,
            let selectedIndexPath = self.tableView.indexPathForSelectedRow,
            let confirmedCell = self.tableView.cellForRow(at: selectedIndexPath) as? FavoritesTableViewDogCell
            else { return }
        
        let confirmedFaveDog = confirmedCell.faveDoggo
        destination.favDog = confirmedFaveDog
    }

    
    func importFaveDoggos(){
        
//        import all the entities of type "FaveDogs", cast them to type of "FaveDogs" class and ADD them to this class's favePack list
        favePack.removeAll()
        let requestf = NSFetchRequest<NSFetchRequestResult>(entityName: "FaveDogs")
        
        do {
            let results: NSArray = try context.fetch(requestf) as NSArray
            for result in results
            {
                let faveDoggy = result as! FaveDogs
                self.favePack.append(faveDoggy)
            }
        }catch{
            print("there was an error importing favorite dogs from memory")
        }
        self.tableView.reloadData()
    }
    func showAlert() {
            let alert = UIAlertController(title: "Connection Error", message: "Issue fetching data, check your connection", preferredStyle: .alert)


            //actions
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in print("Cancel")
            }))
            //show alert
        self.present(alert, animated: true, completion: nil)

    }
    
}
    
    extension FavoritesController: UITableViewDataSource {
        //MARK: DataSource

        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return self.favePack.count
        }
        

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "favoriteDogCell", for: indexPath) as! FavoritesTableViewDogCell
            let fdog = favePack[indexPath.row]
            cell.faveDoggo = fdog
            cell.favoriteDogNameLabel.text = fdog.favoriteDogName
            cell.favoriteDogDescriptionLabel.text = fdog.favoriteDogDescription
            //convert url to UIImage object
            

                DispatchQueue.global(qos: .userInitiated).async {
                    if let dogImageData = NSData(contentsOf: URL(string: fdog.favoriteDogImage!)!){
                        DispatchQueue.main.async {
                            cell.favoriteDogCellImage.image = UIImage(data: dogImageData as Data)
                            cell.favoriteDogCellImage.layer.cornerRadius = cell.favoriteDogCellImage.frame.width / 2
                        }
                    }
                }

            return cell
        }
    }

    extension FavoritesController: UITableViewDelegate {
        //MARK: Delegate

        func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {


              let action = UIContextualAction(style: .normal, title: "Remove",
                handler: { (action, view, completionHandler) in
                // Update data source when user removes dog
                  let unfavoredDog = self.favePack[indexPath.row]
                  self.context.delete(unfavoredDog)

                  //save action
                  do {
                      try self.context.save()
                  } catch {
                      print("unable to unfavorite dog")
                  }
                  self.importFaveDoggos()
                completionHandler(true)
              })
            
                
              action.title = "Unfavorite"
              action.backgroundColor = .red
              let configuration = UISwipeActionsConfiguration(actions: [action])
              return configuration
        }


    }

