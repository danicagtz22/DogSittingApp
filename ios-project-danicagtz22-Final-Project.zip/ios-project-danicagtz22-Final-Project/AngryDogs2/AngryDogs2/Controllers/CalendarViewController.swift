//
//  CalendarViewController.swift
//  AngryDogs2
//
//  Created by Danica Gutierrez 1 on 5/12/23.
//

import UIKit
import EventKit
import EventKitUI

class CalendarViewController: UIViewController{

    let eventStore = EKEventStore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createCalendar()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func addEventAdv(_ sender: Any) {
        switch EKEventStore.authorizationStatus(for: .event)
        {
        case .notDetermined:
            eventStore.requestAccess(to: .event) { granted, error in
                if granted
                {
                    print("Authorized")
                    presentEventVC()
                }
            }
        case .authorized:
            print("Authorized")
            presentEventVC()
        default:
            break
        }
        
        
        func presentEventVC(){
            let eventVC = EKEventEditViewController()
            eventVC.editViewDelegate = self
            eventVC.eventStore = EKEventStore()
            
            let event = EKEvent(eventStore: eventVC.eventStore)
            event.title = "My Event"
            event.startDate = Date()
            
            eventVC.event = event
            
            self.present(eventVC, animated: true, completion: nil)
            
        }
        

    }
        
    func createCalendar(){
        let calendarView = UICalendarView()
        calendarView.translatesAutoresizingMaskIntoConstraints = false
        
        calendarView.calendar = .current
        calendarView.locale = .current
        calendarView.fontDesign = .rounded
        calendarView.delegate = self
        calendarView.layer.cornerRadius = 12
        calendarView.backgroundColor = .white
        
        view.addSubview(calendarView)
        
        
        NSLayoutConstraint.activate([
            calendarView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            calendarView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            calendarView.heightAnchor.constraint(equalToConstant: 450),
            calendarView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 100)
            ])
    }
}
extension CalendarViewController: EKEventEditViewDelegate{
    func eventEditViewController(_ controller: EKEventEditViewController, didCompleteWith action: EKEventEditViewAction) {
        controller.dismiss(animated: true, completion: nil)
    }
}
extension CalendarViewController: UICalendarViewDelegate {
    func calendarView(_ calendarView: UICalendarView, decorationFor dateComponents: DateComponents) -> UICalendarView.Decoration? {
        return nil
    }
}

