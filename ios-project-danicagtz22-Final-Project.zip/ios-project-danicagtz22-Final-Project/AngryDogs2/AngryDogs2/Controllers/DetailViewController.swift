//
//  DetailViewController.swift
//  AngryDogs2
//
//  Created by Danica Gutierrez 1 on 4/8/23.
//

import UIKit
import CoreData

class DetailViewController: UIViewController {

    var firstLoad = true

    var dog: Dog!
    
    
    
    @IBOutlet weak var note: UITextView!

    @IBAction func saveNotes(_ sender: Any) {
        
        let selectedNote: Note? = dog.note

        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context: NSManagedObjectContext = appDelegate.persistentContainer.viewContext
        //if this is a new note
        if(selectedNote == nil){
            let entity = NSEntityDescription.entity(forEntityName: "Note", in: context)
            let newNote = Note(entity: entity!, insertInto: context)
            
            //this should be the number of the cell, or something that associates it to the cell
            newNote.setValue(packGlobal.count as NSNumber, forKey: "id")
            newNote.setValue(dog.name, forKey: "dogBreed")
            newNote.setValue(note.text, forKey: "noteDescription")
            //dog.note?.noteDesc
            do {
                try context.save()
                
            }catch{
                print("context save error")
            }
        }else //edit existing note
        {
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
            do {
                let results: NSArray = try context.fetch(request) as NSArray
                for result in results
                {
                    let noteR = result as! Note
                    if(noteR == selectedNote){
                        noteR.setValue(note.text, forKey: "noteDescription")
                        try context.save()
                    }
                    
                }
            }catch {
                print("Fetch Failed")
            }
        }
    }
   
    
    @IBOutlet weak var dogBreedLabel: UILabel! {
        didSet {
            dogBreedLabel.text = dog.name
        }
     }
    
    @IBOutlet weak var dogSizeLabel: UILabel!{
        didSet {
            dogSizeLabel.text = dog.description
        }
    }
    
    
    @IBOutlet weak var dogImage: UIImageView!{
        didSet {
            DispatchQueue.global(qos: .userInitiated).async {
                let dogImageData = NSData(contentsOf: URL(string: self.dog!.imageUrl)!)
                DispatchQueue.main.async {
                    self.dogImage.image =
                    UIImage(data: dogImageData! as Data)
                }
            }
        }
    }
  
    @IBOutlet weak var avgWeight: UILabel!{
        didSet {
            avgWeight.text = dog.avgWeight
        }
    }
    
    @IBOutlet weak var avgExpectancy: UILabel!{
        didSet {
            avgExpectancy.text = dog.avgExpectancy
        }
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(firstLoad){
            firstLoad = false
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context: NSManagedObjectContext = appDelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
            do {
                let results: NSArray = try context.fetch(request) as NSArray
                for result in results {
                    let noteR = result as! Note
                    if(noteR.dogBreed == dog.name){
                        note.text = noteR.noteDescription
                    }
                    

                }
            }catch {
                print("Fetch Failed")
            }

        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
