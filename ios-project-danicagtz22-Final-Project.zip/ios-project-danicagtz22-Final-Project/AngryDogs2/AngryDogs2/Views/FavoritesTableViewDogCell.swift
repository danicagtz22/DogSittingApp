//
//  FavoritesTableViewDogCell.swift
//  AngryDogs2
//
//  Created by Danica Gutierrez 1 on 5/11/23.
//

import UIKit

class FavoritesTableViewDogCell: UITableViewCell {
    
    var faveDoggo: FaveDogs?

    @IBOutlet weak var favoriteDogNameLabel: UILabel!
    
    @IBOutlet weak var favoriteDogDescriptionLabel: UILabel!
    
    @IBOutlet weak var favoriteDogCellImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
