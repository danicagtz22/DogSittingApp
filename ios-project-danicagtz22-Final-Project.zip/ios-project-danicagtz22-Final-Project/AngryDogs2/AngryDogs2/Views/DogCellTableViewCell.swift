//
//  DogCellTableViewCell.swift
//  AngryDogs2
//
//  Created by Danica Gutierrez 1 on 3/30/23.
//

import UIKit

class DogCellTableViewCell: UITableViewCell {
    @IBOutlet weak var dogNameLabel: UILabel!
    @IBOutlet weak var dogDescription: UILabel!
    @IBOutlet weak var dogImageView: UIImageView!
    
    var kennelClubURL: String!
    
    var dog: Dog? {
        didSet {
            self.dogNameLabel.text = dog?.name
            self.dogDescription.text = dog?.description
            self.accessoryType = dog!.isFavorite ? .checkmark : .none
            self.kennelClubURL = dog!.kennelURL
            
            
            let liked = UIImageView(frame: CGRect(x:0, y: 70, width: 35, height: 32))
            liked.image = UIImage(systemName: "heart.fill")
            liked.tintColor = .systemRed
            
            self.accessoryView = (dog!.isFavorite) ? liked : .none
            
            
            
            DispatchQueue.global(qos: .userInitiated).async {
                if let dogImageData = NSData(contentsOf: URL(string: self.dog!.imageUrl)!){
                    DispatchQueue.main.async {
                        self.dogImageView.image = UIImage(data: dogImageData as Data)
                        self.dogImageView.layer.cornerRadius = self.dogImageView.frame.width / 2
                    }
                }
            }
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

