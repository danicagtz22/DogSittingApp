//
//  DogTest.swift
//  AngryDogs2Tests
//
//  Created by Danica Gutierrez 1 on 4/17/23.
//

import XCTest

@testable import AngryDogs2

final class DogTest: XCTestCase {


    func testDogDebugDescription() {

        let subjectUnderTest  = Dog(
            named: "Xolo",
            description: "Small",
            imageUrl: "https://www.akc.org/wp-content/uploads/2016/10/Xoloitzcuintli-on-White-01-500x486.jpg",
            avgWeight: "10-30 lbs",
            avgExpectancy: "12-15 years", kennelURL: "https://www.akc.org/dog-breeds/pomeranian/")
                
        let actualValue = subjectUnderTest.debugDescription
        
        let expectedValue = "Dog(name: Xolo, description: Small)"
        XCTAssertEqual(actualValue, expectedValue)
    
    }


}
