//
//  DogListViewControllerTests.swift
//  AngryDogs2Tests
//
//  Created by Danica Gutierrez 1 on 4/18/23.
//

import XCTest
@testable import AngryDogs2

final class DogListViewControllerTests: XCTestCase {
    
    var systemUnderTest: DogListViewController!

    override func setUp(){
        
        super.setUp()
        
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let navigationController =
            storyboard.instantiateInitialViewController() as!
            UINavigationController
        self.systemUnderTest = navigationController.topViewController as?
            DogListViewController
        
        UIApplication.shared.windows
            .filter {$0.isKeyWindow}
            .first!
            .rootViewController = self.systemUnderTest
        
        XCTAssertNotNil(navigationController.view)
        XCTAssertNotNil(self.systemUnderTest.view)
        
    }

    func testTableView_loadsBirds(){
        
        //Given
        
        let mockDogService = MockDogService()
        let mockDogs = [
            Dog(named: "Pomeranian", description: "Small", imageUrl:"https://cdn.britannica.com/41/233841-050-4FFECCF1/Pomeranian-dog.jpg", avgWeight: "9-16 lbs", avgExpectancy: "11-14", kennelURL: <#String#>),
            Dog(named: "Yorkie", description: "Small", imageUrl:"https://www.carsonvet.com/sites/default/files/yorkshire-terrier-dog-breed-info.jpg", avgWeight: "9-16 lbs", avgExpectancy: "11-14", kennelURL: <#String#>),
            Dog(named: "Samoyed", description: "Large", imageUrl:"https://cdn.britannica.com/86/235886-050-2A7CC649/Samoyed-dog.jpg", avgWeight: "9-16 lbs", avgExpectancy: "11-14", kennelURL: <#String#>),
        ]
        
        mockDogService.mockDogs = mockDogs
        
        self.systemUnderTest.viewDidLoad()
        self.systemUnderTest.dogService = mockDogService
        
        XCTAssertEqual(0, self.systemUnderTest.tableView.numberOfRows(inSection: 0))
        
        //When
        
        self.systemUnderTest.viewWillAppear(false)
        
        //Then
        
        XCTAssertEqual(mockDogs.count, self.systemUnderTest.pack.count)
        XCTAssertEqual(mockDogs.count, self.systemUnderTest.tableView.numberOfRows(inSection: 0))

    }

    class MockDogService: DogService {
        var mockDogs: [Dog]?
        var mockError: Error?
        
        override func getDogs(completion: @escaping ([Dog]?, Error?) -> ()) {
         completion(mockDogs, mockError)
        }
    }

}
