//
//  DogServiceTests.swift
//  AngryDogs2Tests
//
//  Created by Danica Gutierrez 1 on 4/18/23.
//

import XCTest
@testable import AngryDogs2

final class DogServiceTests: XCTestCase {
    
    var systemUnderTest: DogService!

    override func setUp() {
        self.systemUnderTest =  DogService()
    }

    override func tearDown() {
        self.systemUnderTest = nil
    }

    func testAPI_returnsSuccessfulResult() {

        //Given
        var dogs: [Dog]!
        var error: Error?
        
        let promise = expectation(description: "Completion handler is invoked")
        
        //When
        
        self.systemUnderTest.getDogs(completion: { data, shouldntHappen in
            dogs = data
            error = shouldntHappen
            promise.fulfill()
        })
        
    wait(for: [promise], timeout: 5)
        
        //Then
        
        XCTAssertNotNil(dogs)
        XCTAssertNil(error)
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
